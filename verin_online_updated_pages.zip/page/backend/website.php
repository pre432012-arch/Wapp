<div class="p-4 p-lg-5">
    <div class="d-flex justify-content-between align-items-center mb-5">
        <div>
            <h3 class="fw-bold text-dark mb-1"><i class="fa-solid fa-browser text-xez-primary me-2"></i> ຈັດການເວັບໄຊ
            </h3>
            <p class="text-muted small mb-0">ປັບແຕ່ງຂໍ້ມູນພື້ນຖານ ສີ ແລະທີມຂອງເວັບໄຊທ່ານ</p>
        </div>
    </div>

    <div class="row g-4">
        <!-- Main Form -->
        <div class="col-lg-8">
            <div class="mb-4">
                <label class="form-label text-dark fw-bold small">ຊື່ເວັບໄຊ</label>
                <input type="text" id="site_name" class="form-control py-3" value="<?php echo $config['name']; ?>"
                    style="border-radius: 12px;">
            </div>

            <div class="mb-4">
                <label class="form-label text-dark fw-bold small">ອັບໂຫຼດ Logo ຈາກເຄື່ອງ</label>
                <div class="d-flex align-items-center gap-3">
                    <div class="topup-admin-preview">
                        <img id="site_logo_preview" src="<?= htmlspecialchars((string) ($config['logo'] ?? '')) ?>"
                            alt="Logo" class="<?= empty($config['logo']) ? 'd-none' : '' ?>">
                        <i class="fa-solid fa-image <?= !empty($config['logo']) ? 'd-none' : '' ?>"></i>
                    </div>
                    <div class="flex-grow-1">
                        <input type="file" id="site_logo_file" class="form-control py-3"
                            accept="image/jpeg,image/png,image/gif,image/webp" style="border-radius: 12px;">
                        <small class="text-muted">JPG, PNG, GIF ຫຼື WEBP ບໍ່ເກີນ 8 MB</small>
                    </div>
                </div>
            </div>

            <div class="mb-4">
                <label class="form-label text-dark fw-bold small d-block">ຊຸດທີມສຳເລັດຮູບ (Theme Presets)</label>
                <p class="text-muted small mb-3">ກົດເລືອກຊຸດສີທີ່ຖືກໃຈ ລະບົບຈະຕັ້ງສີຫຼັກ, ສີຮອງ ແລະ ໂໝດການສະແດງຜົນໃຫ້ອັດຕະໂນມັດ — ຫຼືປັບແຕ່ງເອງດ້ານລຸ່ມນີ້</p>
                <div class="row g-2" id="themePresetRow">
                    <div class="col-4 col-md-3">
                        <button type="button" class="theme-preset-btn" data-main="#00d4ff" data-sec="#ff0080" data-mode="dark" data-name="Neon Cyber">
                            <span class="theme-preset-swatch" style="background: linear-gradient(135deg,#00d4ff,#ff0080);"></span>
                            <span class="theme-preset-label">Neon Cyber</span>
                        </button>
                    </div>
                    <div class="col-4 col-md-3">
                        <button type="button" class="theme-preset-btn" data-main="#8b5cf6" data-sec="#ec4899" data-mode="dark" data-name="Royal Purple">
                            <span class="theme-preset-swatch" style="background: linear-gradient(135deg,#8b5cf6,#ec4899);"></span>
                            <span class="theme-preset-label">Royal Purple</span>
                        </button>
                    </div>
                    <div class="col-4 col-md-3">
                        <button type="button" class="theme-preset-btn" data-main="#d4af37" data-sec="#8a6d1e" data-mode="dark" data-name="Gold Premium">
                            <span class="theme-preset-swatch" style="background: linear-gradient(135deg,#d4af37,#8a6d1e);"></span>
                            <span class="theme-preset-label">Gold Premium</span>
                        </button>
                    </div>
                    <div class="col-4 col-md-3">
                        <button type="button" class="theme-preset-btn" data-main="#0ea5e9" data-sec="#06b6d4" data-mode="light" data-name="Ocean Blue">
                            <span class="theme-preset-swatch" style="background: linear-gradient(135deg,#0ea5e9,#06b6d4);"></span>
                            <span class="theme-preset-label">Ocean Blue</span>
                        </button>
                    </div>
                    <div class="col-4 col-md-3">
                        <button type="button" class="theme-preset-btn" data-main="#10b981" data-sec="#059669" data-mode="light" data-name="Emerald">
                            <span class="theme-preset-swatch" style="background: linear-gradient(135deg,#10b981,#059669);"></span>
                            <span class="theme-preset-label">Emerald</span>
                        </button>
                    </div>
                    <div class="col-4 col-md-3">
                        <button type="button" class="theme-preset-btn" data-main="#f472b6" data-sec="#fb7185" data-mode="light" data-name="Sakura Pink">
                            <span class="theme-preset-swatch" style="background: linear-gradient(135deg,#f472b6,#fb7185);"></span>
                            <span class="theme-preset-label">Sakura Pink</span>
                        </button>
                    </div>
                    <div class="col-4 col-md-3">
                        <button type="button" class="theme-preset-btn" data-main="#f97316" data-sec="#ef4444" data-mode="dark" data-name="Sunset">
                            <span class="theme-preset-swatch" style="background: linear-gradient(135deg,#f97316,#ef4444);"></span>
                            <span class="theme-preset-label">Sunset</span>
                        </button>
                    </div>
                    <div class="col-4 col-md-3">
                        <button type="button" class="theme-preset-btn" data-main="#6366f1" data-sec="#8b5cf6" data-mode="light" data-name="Classic Indigo">
                            <span class="theme-preset-swatch" style="background: linear-gradient(135deg,#6366f1,#8b5cf6);"></span>
                            <span class="theme-preset-label">Indigo</span>
                        </button>
                    </div>
                </div>
            </div>

            <div class="row g-3 mb-4">
                <div class="col-md-6">
                    <label class="form-label text-dark fw-bold small text-center d-block">ສີຫຼັກ (Primary)</label>
                    <input type="color" class="form-control form-control-color w-100 py-1" id="site_main_color"
                        value="<?php echo $config['main_color']; ?>" style="height: 60px; border-radius: 12px;">
                </div>
                <div class="col-md-6">
                    <label class="form-label text-dark fw-bold small text-center d-block">ສີຮອງ (Secondary)</label>
                    <input type="color" class="form-control form-control-color w-100 py-1" id="site_sec_color"
                        value="<?php echo $config['sec_color']; ?>" style="height: 60px; border-radius: 12px;">
                </div>
            </div>

            <div class="mb-4">
                <label class="form-label text-dark fw-bold small">ໂໝດການສະແດງຜົນ (Theme)</label>
                <div class="row g-3">
                    <div class="col-6">
                        <input type="radio" class="btn-check" name="theme_mode" id="theme_light" value="light" <?php if (($config['theme_mode'] ?? 'light') == 'light')
                            echo 'checked'; ?>>
                        <label class="btn btn-outline-warning w-100 py-3 fw-bold shadow-none" for="theme_light"
                            style="border-radius: 15px;">
                            <i class="fa-solid fa-sun me-2"></i> Light Mode
                        </label>
                    </div>
                    <div class="col-6">
                        <input type="radio" class="btn-check" name="theme_mode" id="theme_dark" value="dark" <?php if (($config['theme_mode'] ?? 'light') == 'dark')
                            echo 'checked'; ?>>
                        <label class="btn btn-outline-dark w-100 py-3 fw-bold shadow-none" for="theme_dark"
                            style="border-radius: 15px;">
                            <i class="fa-solid fa-moon me-2"></i> Dark Mode
                        </label>
                    </div>
                </div>
            </div>

            <div class="mb-4">
                <label class="form-label text-dark fw-bold small">Webhook Discord</label>
                <input type="text" id="webhook_dc" class="form-control py-3"
                    value="<?php echo $config['webhook_dc']; ?>" style="border-radius: 12px;">
            </div>

            <div class="mb-4">
                <label class="form-label text-dark fw-bold small">Discord Server ID (ສຳລັບ Widget ໃນ Footer)</label>
                <input type="text" id="discord_server" class="form-control py-3"
                    value="<?php echo $config['discord_server'] ?? ''; ?>" style="border-radius: 12px;"
                    placeholder="ເຊັ່ນ 123456789012345678">
                <small class="text-muted">ຊອກຫາ Server ID: ຄລິກຂວາທີ່ເຊີບເວີ > Copy Server ID</small>
            </div>

            <div class="card border-primary mb-4" style="border-radius: 12px;">
                <div class="card-body">
                    <h5 class="fw-bold text-dark mb-3">
                        <i class="fa-solid fa-qrcode text-primary me-2"></i>OnePlay Top-up (LAK)
                    </h5>
                    <div class="mb-3">
                        <label class="form-label text-dark fw-bold small">JVIX API Key</label>
                        <input type="password" id="topup_api_key" class="form-control py-3"
                            placeholder="<?= !empty($config['topup_api_key']) ? 'ຕັ້ງຄ່າແລ້ວ — ປ່ອຍວ່າງເພື່ອໃຊ້ຄ່າເດີມ' : 'ປ້ອນ API Key ຈາກ JVIX' ?>"
                            autocomplete="new-password" style="border-radius: 12px;">
                        <small class="text-muted">ລະບົບຈະບໍ່ສະແດງ API Key ເດີມກັບມາໃນໜ້າເວັບ</small>
                    </div>
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label text-dark fw-bold small">ສະຖານະ</label>
                            <select id="topup_enabled" class="form-select py-3" style="border-radius: 12px;">
                                <option value="1" <?= (int) ($config['topup_enabled'] ?? 1) === 1 ? 'selected' : '' ?>>ເປີດໃຊ້ງານ</option>
                                <option value="0" <?= (int) ($config['topup_enabled'] ?? 1) === 0 ? 'selected' : '' ?>>ປິດໃຊ້ງານ</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label text-dark fw-bold small">ຍອດຂັ້ນຕ່ຳ (ກີບ)</label>
                            <input type="number" id="topup_min_amount" class="form-control py-3"
                                value="<?= (int) ($config['topup_min_amount'] ?? 1000) ?>" min="1">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label text-dark fw-bold small">ຍອດສູງສຸດ (ກີບ)</label>
                            <input type="number" id="topup_max_amount" class="form-control py-3"
                                value="<?= (int) ($config['topup_max_amount'] ?? 100000000) ?>" min="1">
                        </div>
                    </div>
                    <hr class="my-4">
                    <h6 class="fw-bold text-dark mb-3">
                        <i class="fa-solid fa-images text-primary me-2"></i>ຮູບຊ່ອງທາງເຕີມເງິນ
                    </h6>
                    <p class="text-muted small">ເລືອກຮູບຈາກເຄື່ອງ ຖ້າບໍ່ເລືອກຮູບໃໝ່ຈະໃຊ້ຮູບເດີມ</p>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <div class="border rounded-4 p-3 h-100">
                                <div class="topup-admin-preview mb-3">
                                    <img id="topup_redeem_preview"
                                        src="<?= htmlspecialchars((string) ($config['topup_redeem_image'] ?? '')) ?>"
                                        alt="ຮູບແລກໂຄ້ດ"
                                        class="<?= empty($config['topup_redeem_image']) ? 'd-none' : '' ?>">
                                    <i class="fa-solid fa-gift <?= !empty($config['topup_redeem_image']) ? 'd-none' : '' ?>"></i>
                                </div>
                                <label class="form-label text-dark fw-bold small">ອັບໂຫຼດຮູບແລກໂຄ້ດ</label>
                                <input type="file" id="topup_redeem_file" class="form-control"
                                    accept="image/jpeg,image/png,image/gif,image/webp">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="border rounded-4 p-3 h-100">
                                <div class="topup-admin-preview mb-3">
                                    <img id="topup_oneplay_preview"
                                        src="<?= htmlspecialchars((string) ($config['topup_oneplay_image'] ?? '')) ?>"
                                        alt="ຮູບ OnePlay QR"
                                        class="<?= empty($config['topup_oneplay_image']) ? 'd-none' : '' ?>">
                                    <i class="fa-solid fa-qrcode <?= !empty($config['topup_oneplay_image']) ? 'd-none' : '' ?>"></i>
                                </div>
                                <label class="form-label text-dark fw-bold small">ອັບໂຫຼດຮູບ OnePlay QR</label>
                                <input type="file" id="topup_oneplay_file" class="form-control"
                                    accept="image/jpeg,image/png,image/gif,image/webp">
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="mb-4">
                <label class="form-label text-dark fw-bold small">ປະກາດ (ໜ້າຮ້ານ)</label>
                <input type="text" id="ann" class="form-control py-3" value="<?php echo $config['ann']; ?>"
                    style="border-radius: 12px;">
            </div>

            <div class="mb-4">
                <label class="form-label text-dark fw-bold small">ຄຳອະທິບາຍຮ້ານ (Footer)</label>
                <textarea id="site_des" rows="5" class="form-control"
                    style="border-radius: 12px;"><?php echo $config['des']; ?></textarea>
            </div>

            <button class="btn btn-success w-100 py-3 fw-bold shadow-sm" id="btn_regis"
                style="background: linear-gradient(135deg, #22c55e 0%, #16a34a 100%); border: none; border-radius: 12px;">
                <i class="fa-solid fa-save me-2"></i> ບັນທຶກຂໍ້ມູນເວັບໄຊທັງໝົດ
            </button>
        </div>
    </div>
</div>

<style>
    .topup-admin-preview {
        width: 86px;
        height: 86px;
        display: grid;
        place-items: center;
        overflow: hidden;
        color: var(--xez-primary);
        background: rgba(var(--xez-primary-rgb), .1);
        border-radius: 20px;
        font-size: 2rem;
    }

    .topup-admin-preview img {
        width: 100%;
        height: 100%;
        object-fit: contain;
    }

    .theme-preset-btn {
        width: 100%;
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 6px;
        padding: 10px 6px 8px;
        border: 2px solid rgba(15, 23, 42, 0.08);
        border-radius: 14px;
        background: #fff;
        cursor: pointer;
        transition: all .2s ease;
    }

    .theme-preset-btn:hover {
        border-color: rgba(15, 23, 42, 0.2);
        transform: translateY(-2px);
    }

    .theme-preset-btn.active {
        border-color: var(--xez-primary);
        box-shadow: 0 0 0 3px rgba(var(--xez-primary-rgb), .18);
    }

    .theme-preset-swatch {
        width: 100%;
        height: 34px;
        border-radius: 9px;
        display: block;
    }

    .theme-preset-label {
        font-size: 11px;
        font-weight: 600;
        color: #475569;
        text-align: center;
        line-height: 1.2;
    }
</style>

<script type="text/javascript">
    function previewTopupImage(input, previewId) {
        var file = input.files && input.files[0];
        if (!file) return;

        var preview = document.getElementById(previewId);
        preview.src = URL.createObjectURL(file);
        preview.classList.remove('d-none');
        preview.parentElement.querySelector('i').classList.add('d-none');
    }

    function markActivePreset() {
        var main = ($("#site_main_color").val() || '').toLowerCase();
        var sec = ($("#site_sec_color").val() || '').toLowerCase();
        var mode = $('input[name="theme_mode"]:checked').val();
        $(".theme-preset-btn").removeClass("active").each(function () {
            var $b = $(this);
            if (($b.data("main") + '').toLowerCase() === main &&
                ($b.data("sec") + '').toLowerCase() === sec &&
                $b.data("mode") === mode) {
                $b.addClass("active");
            }
        });
    }

    $(".theme-preset-btn").on("click", function () {
        var $b = $(this);
        $("#site_main_color").val($b.data("main"));
        $("#site_sec_color").val($b.data("sec"));
        $("#theme_" + $b.data("mode")).prop("checked", true);
        markActivePreset();
    });
    markActivePreset();

    $("#site_logo_file").on("change", function () {
        previewTopupImage(this, "site_logo_preview");
    });
    $("#topup_redeem_file").on("change", function () {
        previewTopupImage(this, "topup_redeem_preview");
    });

    $("#topup_oneplay_file").on("change", function () {
        previewTopupImage(this, "topup_oneplay_preview");
    });

    $("#btn_regis").click(function (e) {
        e.preventDefault();
        var formData = new FormData();
        formData.append('name', $("#site_name").val());
        formData.append('bg', 'no'); // Fixed BG for now
        formData.append('main_color', $("#site_main_color").val());
        formData.append('sec_color', $("#site_sec_color").val());
        formData.append('contact', $("#site_contact").val() || '#'); // Default if empty
        formData.append('theme_mode', $('input[name="theme_mode"]:checked').val());
        formData.append('des', $("#site_des").val());
        formData.append('ann', $("#ann").val());
        formData.append('webhook_dc', $("#webhook_dc").val());
        formData.append('discord_server', $("#discord_server").val());
        formData.append('topup_api_key', $("#topup_api_key").val());
        formData.append('topup_enabled', $("#topup_enabled").val());
        formData.append('topup_min_amount', $("#topup_min_amount").val());
        formData.append('topup_max_amount', $("#topup_max_amount").val());
        if ($("#site_logo_file")[0].files[0]) {
            formData.append('site_logo_file', $("#site_logo_file")[0].files[0]);
        }
        if ($("#topup_redeem_file")[0].files[0]) {
            formData.append('topup_redeem_file', $("#topup_redeem_file")[0].files[0]);
        }
        if ($("#topup_oneplay_file")[0].files[0]) {
            formData.append('topup_oneplay_file', $("#topup_oneplay_file")[0].files[0]);
        }

        Swal.fire({ title: 'ກຳລັງບັນທຶກ...', didOpen: () => { Swal.showLoading() } });

        $.ajax({
            type: 'POST',
            url: 'system/backend/website.php',
            data: formData,
            contentType: false,
            processData: false,
        }).done(function (res) {
            Swal.fire({ icon: 'success', title: 'ສຳເລັດ', text: res.message }).then(() => window.location.reload());
        }).fail(function (jqXHR) {
            Swal.fire({
                icon: 'error',
                title: 'ຜິດພາດ',
                text: jqXHR.responseJSON?.message || 'ເກີດຂໍ້ຜິດພາດໃນການບັນທຶກຂໍ້ມູນ'
            });
        });
    });
</script>
